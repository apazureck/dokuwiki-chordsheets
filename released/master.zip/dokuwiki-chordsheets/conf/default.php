<?php
/**
 * Default settings for the chordsheets plugin
 *
 * @author Andreas Pazureck <andreas@pazureck.de>
 */

//$conf['fixme']    = 'FIXME';

