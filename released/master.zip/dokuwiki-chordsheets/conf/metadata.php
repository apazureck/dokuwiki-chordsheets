<?php
/**
 * Options for the chordsheets plugin
 *
 * @author Andreas Pazureck <andreas@pazureck.de>
 */


//$meta['fixme'] = array('string');

